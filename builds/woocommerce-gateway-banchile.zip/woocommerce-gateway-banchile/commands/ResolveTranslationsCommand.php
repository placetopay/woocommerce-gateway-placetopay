<?php

use PlacetoPay\PaymentMethod\ResolveTranslations;

include(__DIR__ . '/../src/ResolveTranslations.php');
new ResolveTranslations();
